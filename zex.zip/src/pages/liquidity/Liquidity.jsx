import React from 'react';

function Liquidity(props) {
    return (
        <div>
            liquidity
        </div>
    );
}

export default Liquidity;